<?php

header("Content-Type: text/html");

header('Access-Control-Allow-Origin: http://example1.com');

header('Access-Control-Allow-Credentials: true');

echo "Account Information: Password for superuser account - #$%GHJHV^&UHDFG456789JBV";

?>